parameter DATA_WIDTH = 16;
parameter ADDR_WIDTH = 18;
parameter RAM_DATA_WIDTH = 8;
